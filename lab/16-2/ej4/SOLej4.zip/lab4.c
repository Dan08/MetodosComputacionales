#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double sum_random_numbers(int n);
void many_sums_of_random_numbers(int n,int m);
double average(double *x, int m);
double stdev(double *x, double ave, int m);
int main(void){

    int N[5] = {20,40,60,80,100};
	
	int i;
	for(i=0;i<5;i++){
		many_sums_of_random_numbers(N[i],10000);
	}
    
    return 0;
}

double sum_random_numbers(int n){
    double suma = 0.0;
    int i;
    for(i=0;i<n;i++){
        suma+=drand48();
    }
    return suma;
}

void many_sums_of_random_numbers(int n,int m){
    double *sums = malloc(m*sizeof(double));
    int i;
    for(i=0;i<m;i++){
        sums[i] = sum_random_numbers(n);
    }
	double ave = average(sums, m);
	double std = stdev(sums, ave, m);
    printf("%f %f\n", ave, std);
}

double average(double *x, int m){
    int i;
	double ave = 0;
    for(i=0;i<m;i++){
		ave += x[i];
	}
	return ave/m;
}

double stdev(double *x, double ave, int m){
    int i;
	double std = 0;
    for(i=0;i<m;i++){
		std += pow(x[i]-ave, 2);
	}
	return sqrt(std/(m-1));
}

