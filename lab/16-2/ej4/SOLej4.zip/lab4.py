import matplotlib.pyplot as plt
import numpy as np

A = np.loadtxt("a.dat")
plt.scatter(A[:,0], A[:,1])
plt.xlabel("Promedio")
plt.ylabel("Desviacion estandar")
plt.savefig("fig.png")
